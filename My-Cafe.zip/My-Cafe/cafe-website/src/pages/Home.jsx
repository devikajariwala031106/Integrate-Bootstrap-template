import { Link } from "react-router-dom";
function Home(){
return(

<div>

<section className="hero">

<div className="hero-content">

<h1>CORRETTO</h1>
<p>Perfect Coffee Experience</p>
<Link to="/menu" className="btn btn-warning mt-3">
  Explore Menu
</Link>

</div>

</section>

</div>

)
}

export default Home