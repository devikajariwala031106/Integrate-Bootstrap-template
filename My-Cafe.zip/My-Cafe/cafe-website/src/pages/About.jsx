import react from "react";

function About() {
  return (

    <div className="coffee-bg">

      <div className="container coffee-content text-center">

        <h1>About Our Cafe</h1>

        <p>
          CafeTime is a modern coffee shop where you can enjoy fresh coffee,
          delicious snacks and a relaxing environment.
        </p>

        <div className="row mt-5">

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=600&q=80"
              className="gallery-img"
              alt="coffee"
            />
            <h5 className="mt-3">Fresh Coffee</h5>
            <p>We serve freshly brewed coffee made from premium roasted beans.</p>
          </div>

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80"
              className="gallery-img"
              alt="coffee shop"
            />
            <h5 className="mt-3">Relaxing Place</h5>
            <p>A perfect place to relax, meet friends and enjoy great coffee.</p>
          </div>

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=600&q=80"
              className="gallery-img"
              alt="coffee beans"
            />
            <h5 className="mt-3">Quality Beans</h5>
            <p>We use high quality coffee beans to deliver the best taste.</p>
          </div>

        </div>

      </div>

    </div>

  );
}

export default About;