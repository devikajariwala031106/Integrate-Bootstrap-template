import react from "react";
function Services() {
  return (
    <div className="coffee-bg">
      <div className="container coffee-content text-center">

        <h2 className="mb-5">Our Services</h2>

        <div className="row">

          <div className="col-md-4">
            <div className="menu-card p-3">
              <img
                src="https://images.unsplash.com/photo-1509042239860-f550ce710b93"
                className="gallery-img mb-3"
                alt="coffee"
              />

              <h5 className="text-dark">Fresh Coffee</h5>
              <p className="text-dark">
                We serve freshly brewed coffee made from high-quality roasted beans every day.
              </p>
            </div>
          </div>

          <div className="col-md-4">
            <div className="menu-card p-3">
              <img
                src="https://images.unsplash.com/photo-1511920170033-f8396924c348"
                className="gallery-img mb-3"
                alt="beans"
              />

              <h5 className="text-dark">Quality Beans</h5>
              <p className="text-dark">
         A relaxing and comfortable place where you can enjoy coffee with friends or work peacefully.
              </p>
            </div>
          </div>

          <div className="col-md-4">
            <div className="menu-card p-3">
              <img
                src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085"
                className="gallery-img mb-3"
                alt="cafe"
              />

              <h5 className="text-dark">Relaxing Place</h5>
              <p className="text-dark">
                “A perfect environment to relax with friends or work comfortably.”
              </p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

export default Services;