import React from "react";
function Login(){
  return(
    <div className="coffee-bg">

      <div className="container coffee-content text-center">

        <h2>Login</h2>

        <input className="form-control mb-3" placeholder="Email"/>
        <input className="form-control mb-3" placeholder="Password" type="password"/>

        <button className="btn btn-dark w-100">Login</button>

      </div>

    </div>
  )
}

export default Login