import react from "react";

function Menu(){
return(

<div className="coffee-bg">

<div className="container coffee-content">

<h2 className="text-center mb-5">Coffee Menu</h2>

<div className="row justify-content-center">

<div className="col-md-6">

<div className="menu-card">

<div className="d-flex justify-content-between border-bottom py-2 text-dark">
<span>Cappuccino</span>
<span>₹120</span>
</div>

<div className="d-flex justify-content-between border-bottom py-2 text-dark">
<span>Latte</span>
<span>₹150</span>
</div>

<div className="d-flex justify-content-between border-bottom py-2 text-dark">
<span>Espresso</span>
<span>₹100</span>
</div>

<div className="d-flex justify-content-between border-bottom py-2 text-dark">
<span>Cold Coffee</span>
<span>₹180</span>
</div>

<div className="d-flex justify-content-between py-2 text-dark">
<span>Chocolate Cake</span>
<span>₹140</span>
</div>

</div>

</div>

</div>

</div>

</div>

)
}

export default Menu