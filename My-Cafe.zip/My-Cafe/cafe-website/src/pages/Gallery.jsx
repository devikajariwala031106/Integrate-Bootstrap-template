import React from "react";

function Gallery() {
  return (
    <div className="coffee-bg">

      <div className="container coffee-content text-center">

        <h1 className="mb-5">Gallery</h1>

        <div className="row">

          <div className="col-md-4 mb-4">
            <img
              src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085"
              className="gallery-img"
              alt="coffee"
            />
            <h5 className="mt-3">Fresh Coffee</h5>
            <p>Enjoy our freshly brewed coffee made from premium beans.</p>
          </div>

          <div className="col-md-4 mb-4">
            <img
              src="https://images.unsplash.com/photo-1509042239860-f550ce710b93"
              className="gallery-img"
              alt="coffee cup"
            />
            <h5 className="mt-3">Coffee Moments</h5>
            <p>Perfect place to relax and enjoy coffee with friends.</p>
          </div>

          <div className="col-md-4 mb-4">
            <img
              src="https://images.unsplash.com/photo-1447933601403-0c6688de566e"
              className="gallery-img"
              alt="coffee beans"
            />
            <h5 className="mt-3">Coffee Beans</h5>
            <p>We use high-quality roasted beans for the best taste.</p>
          </div>

        </div>

      </div>

    </div>
  );
}


export default Gallery