import react from "react";

function Blog() {
  return (

    <div className="coffee-bg">

      <div className="container coffee-content text-center">

        <h1 className="mb-5">Cafe Blog</h1>

        <div className="row">

          <div className="col-md-6">
            <div className="menu-card">
              <img
                src="https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=600&q=80"
                className="gallery-img"
                alt="coffee beans"
              />
              <h4 className="mt-3">Best Coffee Beans</h4>
              <p>
                Different types of coffee beans create unique flavors and
                aromas for the perfect coffee experience.
              </p>
            </div>
          </div>

          <div className="col-md-6">
            <div className="menu-card">
              <img
                src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=600&q=80"
                className="gallery-img"
                alt="coffee tips"
              />
              <h4 className="mt-3">Healthy Coffee Tips</h4>
              <p>
                Drinking coffee in moderation can improve focus, energy and
                overall mood.
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>

  );
}

export default Blog;