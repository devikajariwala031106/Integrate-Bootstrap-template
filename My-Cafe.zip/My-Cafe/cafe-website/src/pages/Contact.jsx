import { useState } from "react";

function Contact() {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSent(true);
    setName("");
    setEmail("");
    setMessage("");
  };

  return (
    <div className="coffee-bg">
      <div className="container coffee-content text-center">

        <h2 className="mb-4">Contact Us</h2>

        <form className="menu-card" onSubmit={handleSubmit}>

          <input
            type="text"
            placeholder="Your Name"
            className="form-control mb-3"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <input
            type="email"
            placeholder="Your Email"
            className="form-control mb-3"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <textarea
            placeholder="Message"
            className="form-control mb-3"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />

          <button className="btn btn-dark w-100">
            Send Message
          </button>

        </form>

        {sent && <p className="text-success mt-3">Message sent successfully!</p>}

      </div>
    </div>
  );
}

export default Contact;